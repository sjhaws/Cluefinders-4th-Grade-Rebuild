# Dynamic analysis: finding the ASEQ frame decoder via a memory watchpoint

Run this on a real Linux machine (or WSL) with Wine installed — NOT in a
constrained sandbox. It needs an interactive terminal, which is exactly
what broke in the sandboxed session that produced this project.

## Setup (one-time)

```bash
sudo dpkg --add-architecture i386
sudo apt update
sudo apt install -y wine wine32:i386 wine64 winbind

export WINEARCH=win32
export WINEPREFIX=~/.wine32-cf4
wine wineboot --init
```

## Step 1 — confirm it runs

```bash
cd /path/to/ClueFinders4thGrade
wine 4THADV32.EXE
```

You should see the game start (it will complain about no sound driver if
you don't have a real/configured sound device — click OK / press Enter to
continue past that).

## Step 2 — find a concrete ASEQ resource to target

Pick one you know exists, e.g. the resource `id 0x9b62` inside
`RSC/CLOC01I1.RSC` (used throughout the original research — a 6-frame
animation, offset 0 in that file's `0xff01` entries). You'll need the game
to actually load this specific bundle, which likely means navigating to
that in-game location. If that's impractical, target `cursors.rsc` instead
— it's the cursor animation resource bundle and loads at startup, no
navigation required. See `FINDINGS.md` for why `cursors.rsc` is the easier
target: its loading code is `FUN_00473b3c` @ `0x473b3c`.

## Step 3 — the watchpoint session

```bash
winedbg 4THADV32.EXE
```

At the `Wine-dbg>` prompt:

```
break *0x473b3c
cont
```

When it hits (press Enter / click OK on any dialogs that appear first),
step forward into the resource constructor and find where the loaded
buffer pointer + length end up. Based on the constructor's parameter
layout (see FINDINGS.md), the buffer pointer lands in an object field
around offset +4 and the length around +0x10 — inspect with:

```
info locals
x/8x <object-pointer>+4
```

Once you have the buffer address and length:

```
watch *(char*)<buffer-address>
cont
```

winedbg will break at the very next instruction anywhere in the program
that reads that memory — that instruction is inside (or very near) the
real ASEQ frame decoder. From there:

```
bt
```

...to see the call stack, and note the address of the containing function.
Bring that address back and we can decompile it with Ghidra
(`ghidra_scripts/DecompileFunctions.java` in this project, edit the target
address list) to read the actual algorithm.

## Alternative: gdb via winedbg's gdb proxy

If you're more comfortable in gdb, `winedbg --gdb 4THADV32.EXE` starts a
gdbserver-compatible session; connect with:

```bash
gdb -ex "target remote localhost:<port>" 4THADV32.EXE
```

(winedbg prints the port on startup). gdb's `watch` command works the same
way and many people find gdb's scripting (Python) more pleasant for
automating the "find first reader of this buffer" step.
