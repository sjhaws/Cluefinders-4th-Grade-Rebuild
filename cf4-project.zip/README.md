# ClueFinders 4th Grade Adventures — Web Port

A from-scratch reverse-engineering and web reimplementation of the 1998
CD-ROM game *ClueFinders' 4th Grade Adventures* (The Learning Company),
built from your original CD files.

## Current status

| Piece | Status |
|---|---|
| `.RSC` container format (NE resource tables) | **Solved** |
| `RESOURCE.MAP` / `AUDIO.MAP` catalog parsing | **Solved** |
| Audio extraction (WAVE resources) | **Solved** — raw RIFF/WAVE, no decoding needed |
| Video conversion (Smacker → WebM) | **Solved** — via ffmpeg |
| ASEQ animation container (frame boundaries) | **Solved** |
| ASEQ per-frame pixel codec | **Unsolved** — see `extractor/FINDINGS.md` |
| Web runtime scaffold (Vite + TS + PixiJS) | **Working**, builds and renders |

The single remaining blocker to a fully faithful recreation is decoding
the proprietary per-frame pixel format inside ASEQ animation resources.
Everything else in the pipeline — audio, video, the resource container
format, and the web app scaffold — is confirmed working end-to-end against
your real game files.

## Project layout

```
extractor/            Python asset-extraction pipeline (offline, run once)
  ne_resource.py         NE resource-table parser (the .RSC format)
  parse_maps.py           RESOURCE.MAP / AUDIO.MAP catalog parser
  extract_audio.py        WAVE resource extraction -> .wav files
  extract_video.py        Smacker -> WebM conversion
  extract_images_stub.py  ASEQ container parsing -> raw (undecoded) frames
  build_manifest.py       Combines everything into manifest.json
  FINDINGS.md              Full research notes on the ASEQ codec investigation

dynamic_analysis/     Scripts + instructions to finish cracking the ASEQ
                       codec on a real machine (winedbg memory watchpoint
                       technique) — see dynamic_analysis/README.md

app/                  Runtime web app (Vite + TypeScript + PixiJS)
  src/main.ts             App entry point
  src/ResourceManager.ts   Loads manifest.json, resolves assets
  src/PlaceholderSprite.ts Placeholder renderer for undecoded ASEQ frames
  src/types.ts             Manifest type definitions
```

## Running the extraction pipeline

```bash
cd extractor
python3 -c "
from pathlib import Path
from extract_audio import extract_audio_from_file
from extract_images_stub import extract_aseq_from_file
from extract_video import convert_one
# ... see build_manifest.py for the full orchestration
"
```

(A single top-level `run_all.py` orchestration script is a natural next
addition once you're ready to process the full game rather than a subset.)

## Running the app

```bash
cd app
npm install
npm run dev       # dev server with hot reload
npm run build     # production build to dist/
```

Assets are read from `app/public/assets/` (manifest.json + audio/ + video/
+ images/) — copy the extractor's output there before running.

## Finishing the ASEQ codec

See `extractor/FINDINGS.md` for the complete research trail (what's
confirmed, what's ruled out, and exactly which functions in the game's
`.exe` to look at next), and `dynamic_analysis/README.md` for a ready-to-run
winedbg script to finish the job on a real machine.

## Deploying

The app builds to fully static files (`app/dist/`) — no backend required.
Netlify, Cloudflare Pages, GitHub Pages, or any static host works. Given
the asset volume, lazy-load assets per-scene rather than shipping the full
asset set on first load (the `ResourceManager` is structured to support
this — extend `loadAudio`/add a `loadAseqFrames` following the same
pattern).
