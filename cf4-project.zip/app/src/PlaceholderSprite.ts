import { Container, Graphics, Text, TextStyle } from 'pixi.js';
import type { AseqResourceEntry } from './types';

/**
 * Renders a visible placeholder for an ASEQ animation that hasn't been
 * pixel-decoded yet (see extractor/FINDINGS.md). Shows a labeled box with
 * the correct frame count and a "flipping placeholder" animation so scene
 * layout/timing can be developed now and swapped for real sprites later
 * without touching call sites -- callers just ask for a "sprite" and get
 * this until decodeAseqFrame() exists.
 */
export class PlaceholderSprite extends Container {
  private frameLabel: Text;
  private frameIndex = 0;
  private entry: AseqResourceEntry;
  private elapsed = 0;
  private readonly frameDurationMs = 100;

  constructor(entry: AseqResourceEntry, width = 120, height = 120) {
    super();
    this.entry = entry;

    const box = new Graphics()
      .rect(0, 0, width, height)
      .fill({ color: 0x552288, alpha: 0.85 })
      .stroke({ color: 0xffffff, width: 2 });
    this.addChild(box);

    const style = new TextStyle({
      fill: 0xffffff,
      fontSize: 12,
      align: 'center',
      wordWrap: true,
      wordWrapWidth: width - 10,
    });
    const title = new Text({ text: `${entry.bundle}\n#${entry.resource_id}`, style });
    title.x = 5;
    title.y = 5;
    this.addChild(title);

    this.frameLabel = new Text({ text: '', style });
    this.frameLabel.x = 5;
    this.frameLabel.y = height - 20;
    this.addChild(this.frameLabel);

    this.updateFrameLabel();
  }

  private updateFrameLabel() {
    this.frameLabel.text = `frame ${this.frameIndex + 1}/${this.entry.frame_count}`;
  }

  /** Call from your app's ticker with deltaMS to cycle the placeholder
   * through the correct frame count at roughly the right cadence. */
  tick(deltaMs: number) {
    this.elapsed += deltaMs;
    if (this.elapsed >= this.frameDurationMs) {
      this.elapsed = 0;
      this.frameIndex = (this.frameIndex + 1) % this.entry.frame_count;
      this.updateFrameLabel();
    }
  }
}
