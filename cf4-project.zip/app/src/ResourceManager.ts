import type { GameManifest, AseqResourceEntry } from './types';

/**
 * Loads manifest.json and provides lookups for audio/video/animation
 * assets. Assets are lazy-loaded by scene (see loadAudio/loadVideo) rather
 * than all upfront -- the full asset set is large (hundreds of MB), and
 * nothing forces a visitor to download the whole game just to open the app.
 */
export class ResourceManager {
  private manifest!: GameManifest;
  private audioCache = new Map<string, HTMLAudioElement>();

  async load(manifestUrl = '/assets/manifest.json'): Promise<void> {
    const res = await fetch(manifestUrl);
    if (!res.ok) {
      throw new Error(`Failed to load manifest: ${res.status} ${res.statusText}`);
    }
    this.manifest = await res.json();
  }

  get notes(): string {
    return this.manifest.notes;
  }

  /** Resource-name lookup exactly like the original RESOURCE.MAP/AUDIO.MAP,
   * e.g. resolveNamed('cloc01.rsc', 'WAVE', 7000). */
  resolveNamed(bundle: string, type: string, id: number): boolean {
    const entries = this.manifest.bundles[bundle.toLowerCase()];
    if (!entries) return false;
    return entries.some(([t, i]) => t === type && i === id);
  }

  getAudioUrl(bundle: string, id: number): string | undefined {
    const key = `${bundle.toLowerCase().replace(/\.rsc$/, '')}_${id}`;
    const filename = this.manifest.audio_files[key];
    return filename ? `/assets/audio/${filename}` : undefined;
  }

  async loadAudio(bundle: string, id: number): Promise<HTMLAudioElement | undefined> {
    const url = this.getAudioUrl(bundle, id);
    if (!url) return undefined;
    if (this.audioCache.has(url)) return this.audioCache.get(url);
    const audio = new Audio(url);
    this.audioCache.set(url, audio);
    return audio;
  }

  getVideoUrl(name: string): string | undefined {
    const filename = this.manifest.video_files[name.toLowerCase()];
    return filename ? `/assets/video/${filename}` : undefined;
  }

  /** ASEQ (animation) resources -- container/frame metadata is available,
   * but frames are NOT decoded pixel data yet. See AseqResourceEntry.decoded. */
  getAseqResource(bundle: string, id: number): AseqResourceEntry | undefined {
    return this.manifest.aseq_resources.find(
      (r) => r.bundle === bundle.toLowerCase() && r.resource_id === id
    );
  }

  listAseqForBundle(bundle: string): AseqResourceEntry[] {
    return this.manifest.aseq_resources.filter((r) => r.bundle === bundle.toLowerCase());
  }
}
