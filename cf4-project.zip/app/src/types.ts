// Types mirroring extractor/build_manifest.py's manifest.json output.

export interface AseqResourceEntry {
  bundle: string;
  resource_id: number;
  frame_count: number;
  unknown_header_fields: [number, number, number, number, number];
  frame_files: string[];
  decoded: false; // pixel codec not yet solved -- see extractor/FINDINGS.md
}

export interface GameManifest {
  generated_from: string;
  bundles: Record<string, [string, number][]>;
  audio_files: Record<string, string>;
  video_files: Record<string, string>;
  aseq_resources: AseqResourceEntry[];
  notes: string;
}
