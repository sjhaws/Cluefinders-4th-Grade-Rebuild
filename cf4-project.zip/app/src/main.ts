import { Application, Container } from 'pixi.js';
import { ResourceManager } from './ResourceManager';
import { PlaceholderSprite } from './PlaceholderSprite';

async function main() {
  const mount = document.getElementById('app')!;

  const app = new Application();
  await app.init({
    width: 640,
    height: 480,
    backgroundColor: 0x000000,
    antialias: false, // this is a 1998 8-bit-indexed game; keep pixels crisp later
  });
  mount.appendChild(app.canvas);

  const resources = new ResourceManager();
  try {
    await resources.load();
  } catch (err) {
    renderLoadError(app.stage, String(err));
    return;
  }

  // Demo scene: lay out every ASEQ animation found in one bundle as
  // placeholders, so layout/timing work can proceed while the pixel codec
  // is still unsolved (see extractor/FINDINGS.md).
  const bundle = 'cloc01i1';
  const entries = resources.listAseqForBundle(bundle);

  const sceneRoot = new Container();
  app.stage.addChild(sceneRoot);

  const placeholders: PlaceholderSprite[] = [];
  entries.forEach((entry, i) => {
    const sprite = new PlaceholderSprite(entry);
    sprite.x = 10 + (i % 5) * 125;
    sprite.y = 10 + Math.floor(i / 5) * 125;
    sceneRoot.addChild(sprite);
    placeholders.push(sprite);
  });

  if (entries.length === 0) {
    renderLoadError(
      app.stage,
      `No ASEQ resources found for bundle "${bundle}" in the manifest.\n` +
        `Run the extractor pipeline against your game files first \u2014 ` +
        `see extractor/README.md.`
    );
  }

  app.ticker.add((ticker) => {
    for (const p of placeholders) p.tick(ticker.deltaMS);
  });
}

function renderLoadError(stage: Container, message: string) {
  console.error(message);
  const el = document.createElement('pre');
  el.style.color = '#fff';
  el.style.fontFamily = 'monospace';
  el.style.padding = '20px';
  el.textContent = message;
  document.getElementById('app')!.appendChild(el);
}

main();
