import struct

def decode_rle8(data, max_width=2000, max_height=2000):
    """Decode standard Windows BI_RLE8 bitmap compression.
    Returns list of rows (each a bytearray) or raises on malformed stream."""
    rows = [bytearray()]
    x = 0
    i = 0
    n = len(data)
    ops = []
    while i < n - 1:
        count = data[i]
        value = data[i+1]
        i += 2
        if count > 0:
            rows[-1].extend([value] * count)
            x += count
            ops.append(('run', count, value))
        else:
            # escape
            if value == 0x00:
                # end of line
                rows.append(bytearray())
                x = 0
                ops.append(('eol',))
            elif value == 0x01:
                ops.append(('eob',))
                break
            elif value == 0x02:
                if i + 1 >= n:
                    break
                dx, dy = data[i], data[i+1]
                i += 2
                ops.append(('delta', dx, dy))
                for _ in range(dy):
                    rows.append(bytearray())
                rows[-1].extend([0] * dx)
                x += dx
            else:
                # absolute mode: 'value' literal bytes follow
                lit_count = value
                lits = data[i:i+lit_count]
                rows[-1].extend(lits)
                i += lit_count
                if lit_count % 2 == 1:
                    i += 1  # padding to word boundary
                x += lit_count
                ops.append(('abs', lit_count))
        if len(rows) > max_height or x > max_width:
            raise ValueError(f"blew past bounds at op {len(ops)}: rows={len(rows)} x={x}")
    return rows, ops

if __name__ == '__main__':
    for fname in ['bg_candidate_0_0x9b58.bin', 'bg_candidate_1_0x9b61.bin']:
        path = f'/home/claude/cf4-project/{fname}'
        chunk = open(path, 'rb').read()
        payload = chunk[14:]
        print(f"=== {fname}: payload {len(payload)} bytes ===")
        try:
            rows, ops = decode_rle8(payload)
            lengths = [len(r) for r in rows]
            print("num rows:", len(rows))
            print("row length distribution (first 20):", lengths[:20])
            print("min/max row length:", min(lengths), max(lengths))
            print("last few ops:", ops[-5:])
        except Exception as e:
            print("FAILED:", e)
