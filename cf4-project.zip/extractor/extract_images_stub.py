"""
extract_images_stub.py

Extracts ASEQ (type 0xff01) resources' CONTAINER structure -- correctly
segmented into individual frames -- and writes out each frame's raw
(still-encoded) bytes plus metadata. It does NOT decode pixels: that part
of the format is unsolved. See FINDINGS.md.

This still has real value:
  - It preserves every frame boundary correctly, verified against the
    game's own resource-table-reading code.
  - It lets the runtime app manifest reference the right number of frames
    per animation now, with placeholder art, so app development isn't
    blocked on the codec.
  - The dumped raw frame bytes are exactly what a future decoder needs as
    input -- nothing is lost by extracting now vs. later.

Usage:
    python3 extract_images_stub.py <rsc_dir> <output_dir>
"""
import json
import sys
from pathlib import Path

from ne_resource import NEResourceFile, TYPE_ASEQ, parse_aseq_container


def extract_aseq_from_file(rsc_path: Path, out_dir: Path) -> list:
    try:
        rf = NEResourceFile(str(rsc_path))
    except Exception as e:
        print(f"  skip {rsc_path.name}: {e}", file=sys.stderr)
        return []

    bundle_stem = rsc_path.stem.lower()
    records = []
    for entry in rf.entries_of_type(TYPE_ASEQ):
        raw = rf.bytes_for(entry)
        try:
            container = parse_aseq_container(raw)
        except Exception as e:
            print(f"  {rsc_path.name} id={entry.numeric_id}: parse failed ({e})", file=sys.stderr)
            continue

        frame_paths = []
        res_dir = out_dir / bundle_stem / str(entry.numeric_id)
        res_dir.mkdir(parents=True, exist_ok=True)
        for frame in container.frames:
            fname = f"frame_{frame.index:03d}.raw"
            (res_dir / fname).write_bytes(frame.data)
            frame_paths.append(str((res_dir / fname).relative_to(out_dir)))

        records.append({
            "bundle": bundle_stem,
            "resource_id": entry.numeric_id,
            "frame_count": container.frame_count,
            "unknown_header_fields": container.unknown_fields,
            "frame_files": frame_paths,
            "decoded": False,  # pixel codec not yet solved
        })
    return records


def main():
    rsc_dir = Path(sys.argv[1])
    out_dir = Path(sys.argv[2])
    out_dir.mkdir(parents=True, exist_ok=True)

    all_records = []
    rsc_files = sorted(set(sorted(rsc_dir.glob("*.RSC")) + sorted(rsc_dir.glob("*.rsc"))))
    for rsc_path in rsc_files:
        recs = extract_aseq_from_file(rsc_path, out_dir)
        if recs:
            print(f"{rsc_path.name}: {len(recs)} ASEQ resources ({sum(r['frame_count'] for r in recs)} frames total)")
        all_records.extend(recs)

    index_path = out_dir / "aseq_index.json"
    index_path.write_text(json.dumps(all_records, indent=2))
    print(f"\n{len(all_records)} ASEQ resources indexed -> {index_path}")
    print("NOTE: frames are still pixel-codec-encoded, not images. See FINDINGS.md.")


if __name__ == "__main__":
    main()
