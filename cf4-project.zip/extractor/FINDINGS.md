# ASEQ Image Codec — Research Notes & Open Problem

Status as of this session: **container format solved, per-frame pixel codec unsolved.**
This document exists so the next session (or another engineer) doesn't repeat
the same dead ends.

## What's confirmed and safe to build on

### Container format (SOLVED)
Every ASEQ resource (NE resource type `0xff01`) has this structure — verified
both by hand-parsing real files AND by cross-checking against the game's own
resource-offset-calculation code in `4THADV32.EXE` via Ghidra decompilation
(function `FUN_00464064` computes `offset = rn_off << align_shift`, matching
our model exactly):

```
u16 marker           (always 1 in every sample seen)
u16 frame_count
u16 unknown_a        (constant per-file, e.g. 12)
u16 unknown_b        (constant per-file, e.g. 15)
u16 unknown_c        (constant, = 1 in all samples)
u16 padding (= 0)
u16 padding (= 0)
-- if frame_count > 1: --
(frame_count - 1) x u32   absolute byte offsets = frame boundaries
-- then: --
frame_count frame data segments, contiguous, spanning to end of resource
```

Implemented in `ne_resource.py::parse_aseq_container()`.

Single-frame resources (frame_count == 1, no boundary table) are likely
backgrounds/stills. Multi-frame resources (found in `*I1.RSC`/`*I2.RSC`/
`*I3.RSC`/`*O1.RSC` scene-asset files) are likely character animation cels.

### What's NOT solved: the per-frame pixel codec

Byte-frequency analysis of frame payloads shows values `0x00`, `0x01`, `0xFF`
overwhelmingly dominant — consistent with delta/differential encoding
(each frame stored as a diff from a reference), not a raw or simply-RLE'd
bitmap.

**Ruled out:**
- Standard Windows `BI_RLE8` bitmap compression — implemented and tested
  (`try_rle8.py` in the original session). Fails cleanly: either blows past
  sane row/height bounds or produces wildly inconsistent row lengths. This
  is NOT the codec.

**Static analysis trail (Ghidra), for whoever picks this up next:**
- The base "Resource" C++ class (vtable @ `0x4dd258` in the binary) does
  *purely generic* file I/O — open/seek/read raw bytes, nothing type-specific.
  Its virtual "load" method is `FUN_00463eb2`.
- This base class is constructed from exactly TWO call sites in the whole
  binary:
  - `FUN_00473b3c` — specific to `cursors.rsc`, uses its own subclass vtable
    at `0x4e7838`. Investigated: the vtable slot matching the base class's
    "load" slot (`FUN_0048a1bc`) turned out to be a version-string formatter
    (`"%d.%d.%d.%d"`), not a decoder. Dead end.
  - `FUN_00456ab0` — generic factory, itself only referenced as **data**
    (a function pointer stored at `0x4d39a4`), not called directly anywhere.
    That storage location turned out to be part of a larger structure
    containing a `"%d %81s"` format string plus a cluster of function
    pointers (`FUN_00456d68`, `FUN_00456d33`, `FUN_00456d4c`, `0x45769c`,
    `FUN_004577c8`, `FUN_00456a7b`, `FUN_00456a94`) — most likely generic
    Borland OWL/RTTI class-registration metadata, not a resource-type
    dispatch table. A raw byte-pattern search for this structure's base
    address anywhere else in the 1MB binary returned **zero hits** — it's
    not reachable via any static reference, confirming this is a dead end
    for static analysis.
- Conclusion from statics: resource *loading* is 100% type-agnostic in this
  engine. The ASEQ-specific interpretation happens later, in whatever code
  reads the loaded buffer and walks frames — this was not located via
  static analysis in the time available.

**Dynamic analysis — validated approach, blocked by tooling, not theory:**
The game genuinely runs under Wine (confirmed: real rendered dialog boxes
from the game's own code, e.g. the "no sound driver" warning). `winedbg`
successfully attaches and resolves breakpoints against the exact same
addresses found via Ghidra (e.g. `break *0x473b3c` resolves correctly to
`4thadv32+0x73b3c`), confirming no rebasing/ASLR complications.

The technique that would very likely crack this: set a breakpoint after the
file-read call that loads a known ASEQ resource (e.g. from
`CLOC01I1.RSC`), get the returned buffer's address, set a **memory
watchpoint** on that buffer, `continue`, and let the debugger break at the
first instruction elsewhere in the code that touches those bytes — that
instruction is the start of the real decoder.

This was not completed because orchestrating Xvfb + Wine + a scripted
debugger session (with GUI dialogs needing dismissal) inside the sandboxed
tool environment used for this session hit a structural problem:
`wineserver` deliberately detaches from its parent process, which broke the
sandbox's command-completion detection. This is an environment limitation,
not a flaw in the approach. **Recommended next step:** run this on a real
machine (Linux or WSL) with a normal terminal — the same technique should
resolve quickly there. A ready-to-adapt winedbg + expect script skeleton is
in `dynamic_analysis/` for this purpose.

## Practical fallback while this is unsolved

- Audio and video assets are fully extractable now (see `extract_audio.py`,
  `extract_video.py`) — most of the game's content by volume.
- The ASEQ *container* can still be parsed and frame boundaries correctly
  identified even without pixel decoding — `extract_images_stub.py` dumps
  each frame's raw (still-encoded) bytes plus metadata, so no data is lost
  and the runtime app can be built against a manifest that has placeholder
  entries ready to swap in real decoded images once the codec is cracked.
